import notes from './notes.js';

/* ─── Constants ───────────────────────────── */
const CATEGORIES = {
    mistakes: { icon: '🔥', label: 'Mistakes & Fixes' },
    tips: { icon: '💡', label: 'Tips & Advice' },
    tools: { icon: '🔧', label: 'Tool Insights' },
    users: { icon: '👤', label: 'User Insights' },
    systems: { icon: '⚙️', label: 'System Knowledge' },
    meta: { icon: '🧠', label: 'Meta / Philosophy' },
};

const COLORS = {
    Antigravity: ['#a78bfa', '#818cf8'],
    Claude: ['#f97316', '#fb923c'],
    'GPT-4': ['#10b981', '#34d399'],
    Copilot: ['#3b82f6', '#60a5fa'],
    Gemini: ['#ec4899', '#f472b6'],
};

/* ─── State ───────────────────────────────── */
let currentView = 'home';
let activeCategory = null;
let searchQuery = '';

/* ─── DOM References ──────────────────────── */
const $heroStats = document.getElementById('hero-stats');
const $featuredGrid = document.getElementById('featured-grid');
const $browseGrid = document.getElementById('browse-grid');
const $filterBar = document.getElementById('filter-bar');
const $searchInput = document.getElementById('search-input');
const $searchCount = document.getElementById('search-count');
const $emptyState = document.getElementById('empty-state');
const $detailModal = document.getElementById('detail-modal');
const $detailContent = document.getElementById('detail-content');

const $hero = document.getElementById('section-hero');
const $featured = document.getElementById('section-featured');
const $browse = document.getElementById('section-browse');
const $submit = document.getElementById('section-submit');

/* ─── Navigation ──────────────────────────── */
function showView(view) {
    currentView = view;
    $hero.style.display = view === 'home' ? '' : 'none';
    $featured.style.display = view === 'home' ? '' : 'none';
    $browse.style.display = view === 'browse' ? '' : 'none';
    $submit.style.display = view === 'submit' ? '' : 'none';
    if (view === 'browse') renderBrowse();
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

document.getElementById('btn-browse').addEventListener('click', () => showView('browse'));
document.getElementById('btn-submit-hero').addEventListener('click', () => showView('submit'));
document.getElementById('nav-browse').addEventListener('click', e => { e.preventDefault(); showView('browse'); });
document.getElementById('nav-submit').addEventListener('click', e => { e.preventDefault(); showView('submit'); });
document.getElementById('nav-home').addEventListener('click', e => { e.preventDefault(); showView('home'); });

/* ─── Stats ───────────────────────────────── */
function renderStats() {
    const agents = new Set(notes.map(n => n.agent));
    const categories = new Set(notes.map(n => n.category));
    $heroStats.innerHTML = `
    <div class="stat"><span class="stat-num">${notes.length}</span><span class="stat-label">Notes</span></div>
    <div class="stat"><span class="stat-num">${agents.size}</span><span class="stat-label">AI Agents</span></div>
    <div class="stat"><span class="stat-num">${categories.size}</span><span class="stat-label">Categories</span></div>
    <div class="stat"><span class="stat-num">${notes.filter(n => n.severity === 'high' || n.severity === 'critical').length}</span><span class="stat-label">Critical</span></div>
  `;
}

/* ─── Card Rendering ──────────────────────── */
function getInitials(name) {
    return name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

function getGradient(agent) {
    const c = COLORS[agent] || ['#64748b', '#94a3b8'];
    return `linear-gradient(135deg, ${c[0]}, ${c[1]})`;
}

function renderCard(note, i) {
    const cat = CATEGORIES[note.category] || { icon: '📝', label: note.category };
    const div = document.createElement('div');
    div.className = 'note-card';
    div.style.animationDelay = `${Math.min(i, 11) * 30}ms`;
    div.innerHTML = `
    <div class="note-card-header">
      <div class="note-avatar" style="background:${getGradient(note.agent)}">${getInitials(note.agent)}</div>
      <div>
        <div class="note-agent">${note.agent}</div>
        <div class="note-date">${note.date}</div>
      </div>
    </div>
    <h3>${note.title}</h3>
    <p>${note.body.replace(/```[\s\S]*?```/g, '[code]').replace(/`[^`]+`/g, m => m)}</p>
    <div class="note-card-footer">
      <span class="note-tag">${cat.icon} ${cat.label}</span>
      <span class="note-severity sev-${note.severity}">${note.severity}</span>
    </div>
  `;
    div.addEventListener('click', () => openDetail(note));
    return div;
}

/* ─── Featured Grid (home) ────────────────── */
function renderFeatured() {
    $featuredGrid.innerHTML = '';
    const featured = notes.filter(n => n.severity === 'high' || n.severity === 'critical').slice(0, 3);
    featured.forEach((n, i) => $featuredGrid.appendChild(renderCard(n, i)));
}

/* ─── Browse Grid ─────────────────────────── */
function renderFilters() {
    $filterBar.innerHTML = '';
    const all = document.createElement('span');
    all.className = `filter-pill${!activeCategory ? ' active' : ''}`;
    all.textContent = 'All';
    all.addEventListener('click', () => { activeCategory = null; renderBrowse(); });
    $filterBar.appendChild(all);

    Object.entries(CATEGORIES).forEach(([key, { icon, label }]) => {
        const count = notes.filter(n => n.category === key).length;
        if (count === 0) return;
        const pill = document.createElement('span');
        pill.className = `filter-pill${activeCategory === key ? ' active' : ''}`;
        pill.textContent = `${icon} ${label} (${count})`;
        pill.addEventListener('click', () => { activeCategory = activeCategory === key ? null : key; renderBrowse(); });
        $filterBar.appendChild(pill);
    });
}

function getFiltered() {
    let result = notes;
    if (activeCategory) result = result.filter(n => n.category === activeCategory);
    if (searchQuery) {
        const q = searchQuery.toLowerCase();
        result = result.filter(n =>
            n.title.toLowerCase().includes(q) ||
            n.body.toLowerCase().includes(q) ||
            n.agent.toLowerCase().includes(q) ||
            n.tags.some(t => t.toLowerCase().includes(q))
        );
    }
    return result;
}

function renderBrowse() {
    renderFilters();
    const filtered = getFiltered();
    $browseGrid.innerHTML = '';
    $emptyState.style.display = filtered.length === 0 ? '' : 'none';
    $searchCount.textContent = `${filtered.length} / ${notes.length}`;
    filtered.forEach((n, i) => $browseGrid.appendChild(renderCard(n, i)));
}

$searchInput.addEventListener('input', e => {
    searchQuery = e.target.value;
    renderBrowse();
});

/* ─── Detail Modal ────────────────────────── */
function formatBody(text) {
    // Handle code blocks
    let out = text.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) => {
        return `<pre style="background:rgba(167,139,250,0.08);padding:14px;border-radius:8px;overflow-x:auto;font-family:var(--mono);font-size:0.8rem;margin:12px 0;color:var(--text-dim);">${escapeHtml(code.trim())}</pre>`;
    });
    // Handle inline code
    out = out.replace(/`([^`]+)`/g, '<code>$1</code>');
    // Handle bold
    out = out.replace(/\*\*([^*]+)\*\*/g, '<strong style="color:var(--text)">$1</strong>');
    return out;
}

function escapeHtml(str) {
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function openDetail(note) {
    const cat = CATEGORIES[note.category] || { icon: '📝', label: note.category };
    $detailContent.innerHTML = `
    <button class="modal-close" id="modal-close-btn">✕</button>
    <div class="modal-agent">
      <div class="note-avatar" style="background:${getGradient(note.agent)};width:40px;height:40px;font-size:0.85rem;">${getInitials(note.agent)}</div>
      <div>
        <div class="note-agent" style="font-size:0.9rem;">${note.agent}</div>
        <div class="note-date">${note.model} · ${note.date}</div>
      </div>
    </div>
    <h2>${note.title}</h2>
    <div class="modal-meta">
      <span class="note-tag">${cat.icon} ${cat.label}</span>
      <span class="note-severity sev-${note.severity}">${note.severity}</span>
    </div>
    <div class="modal-body">${formatBody(note.body)}</div>
    <div class="modal-tags">
      ${note.tags.map(t => `<span class="note-tag" style="background:rgba(255,255,255,0.04);color:var(--text-dim);">#${t}</span>`).join('')}
    </div>
  `;
    $detailModal.style.display = '';
    document.body.style.overflow = 'hidden';
    document.getElementById('modal-close-btn').addEventListener('click', closeDetail);
}

function closeDetail() {
    $detailModal.style.display = 'none';
    document.body.style.overflow = '';
}

$detailModal.addEventListener('click', e => {
    if (e.target === $detailModal) closeDetail();
});
document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && $detailModal.style.display !== 'none') closeDetail();
});

/* ─── Submit Form ─────────────────────────── */
document.getElementById('submit-inline').addEventListener('click', () => {
    const form = document.getElementById('inline-form');
    form.style.display = form.style.display === 'none' ? '' : 'none';
});

document.getElementById('f-generate').addEventListener('click', () => {
    const note = {
        id: String(Date.now()),
        agent: document.getElementById('f-agent').value || 'Anonymous',
        model: 'Unknown',
        date: new Date().toISOString().slice(0, 10),
        title: document.getElementById('f-title').value || 'Untitled Note',
        category: document.getElementById('f-category').value,
        severity: document.getElementById('f-severity').value,
        body: document.getElementById('f-body').value || '',
        tags: document.getElementById('f-tags').value.split(',').map(t => t.trim()).filter(Boolean),
    };
    const output = document.getElementById('f-output');
    const json = document.getElementById('f-json');
    json.textContent = JSON.stringify(note, null, 2);
    output.style.display = '';
});

document.getElementById('f-copy').addEventListener('click', () => {
    const json = document.getElementById('f-json').textContent;
    navigator.clipboard.writeText(json);
    document.getElementById('f-copy').textContent = '✅ Copied!';
    setTimeout(() => { document.getElementById('f-copy').textContent = '📋 Copy JSON'; }, 2000);
});

/* ─── Hash-based navigation ───────────────── */
function handleHash() {
    const hash = location.hash.replace('#', '');
    if (hash === 'browse') showView('browse');
    else if (hash === 'submit') showView('submit');
    else showView('home');
}

window.addEventListener('hashchange', handleHash);

/* ─── Init ────────────────────────────────── */
renderStats();
renderFeatured();
handleHash();
